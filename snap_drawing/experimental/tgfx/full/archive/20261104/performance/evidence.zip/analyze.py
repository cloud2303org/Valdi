from pathlib import Path
import hashlib
import json
import math
import statistics
import subprocess
import zipfile

E = Path("/tmp/valdi-tgfx-performance-20261104")
W = Path("/Users/cloud/.config/superpowers/worktrees/Valdi-node-only/tgfx-prototype-20261104")
P = W / "snap_drawing/experimental/tgfx/full/performance"
expected = {
    "managed": ["cached-vector", "shaped-text", "image-svg", "lottie"],
    "native": ["vector", "text", "bitmap", "svg", "lottie"],
}


def digest(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()


def nearest(values, percentile):
    return sorted(values)[math.ceil(len(values) * percentile) - 1]


def aggregate(values):
    return {
        "median": statistics.median(values),
        "min": min(values),
        "max": max(values),
        "runs": values,
    }


summary = {
    "schema": 1,
    "date": "2026-11-04",
    "sourceRoot": str(W),
    "scope": "Current complete replacement, including Lottie; simulator/emulator evidence",
    "onScreenFps": None,
    "phoneEnergyJoules": None,
    "phonePowerWatts": None,
    "iosDeviceShippingSizeBytes": None,
    "method": {
        "size": [360, 640],
        "warmupsPerScene": 30,
        "measuredFramesPerScenePerRun": 300,
        "runsPerBackendPerPlatformPerFamily": 3,
        "order": ["skia-1", "tgfx-1", "tgfx-2", "skia-2", "skia-3", "tgfx-3"],
        "aggregation": "Median of the three run means; median of within-run nearest-rank P95s",
        "completion": "Synchronous owned RGBA readback, not GPU submission alone",
        "settle": "Eight foreground seconds, then native warmup; no builds during sampling",
        "managed": "Actual Hermes bitmap API: Skia CPU raster vs TGFX GPU upload/render/readback",
        "native": "Both real GPU paths: Android GLES; Apple Metal",
        "power": "Process CPU time is activity only; no physical-device energy measurement",
        "dependencies": (
            "Same outer opt/production flags. Imported TGFX/ThorVG retain their recorded "
            "vendor builds; not normalized compiler settings or a renderer-only microbenchmark. "
            "Android TGFX effective -Os, ThorVG optimization 3 with SIMD, no LTO."
        ),
    },
    "measurements": {},
    "reports": [],
}
envelope = json.loads((E / "input-envelope.json").read_text())
current = {}
for profile, wanted in envelope["profileSourceState"].items():
    value = subprocess.check_output(
        ["node", str(W / "snap_drawing/experimental/tgfx/full/app/bridge/source-state.mjs"),
         str(W), profile],
        text=True,
    ).strip()
    assert value == wanted, (profile, value, wanted)
    current[profile] = value
summary["sourceState"] = current
report_hashes = set()

for family in expected:
    summary["measurements"][family] = {}
    for platform in ["android", "ios"]:
        backends = {}
        for backend in ["skia", "tgfx"]:
            runs = []
            cpu = []
            for trial in [1, 2, 3]:
                folder = E / "trials" / family / platform / f"{backend}-{trial}"
                file = folder / "report.json"
                report = json.loads(file.read_text())
                collection = json.loads((folder / "collection.json").read_text())
                sha = digest(file)
                assert collection["reportSha256"] == sha
                assert sha not in report_hashes
                report_hashes.add(sha)
                summary["reports"].append({
                    "family": family, "platform": platform, "backend": backend,
                    "trial": trial, "path": str(file), "sha256": sha,
                    "collectedUnixMs": collection["collectedUnixMs"],
                    "sourceMtime": collection["sourceMtime"],
                })
                if family == "managed":
                    assert report["status"] == "PASS" and report["completed"]
                    assert report["backend"] == backend
                    assert report["startupSettleMs"] == 8000
                    assert report["sceneCount"] == 4
                    assert collection["done"] == f"{backend} PASS"
                    scenes = [
                        e["event"]["result"] for e in report["events"]
                        if e["event"]["kind"] == "scene"
                    ]
                    assert [s["id"] for s in scenes] == expected[family]
                    assert report["provenance"]["sourceStateSha256"] == current[
                        "android_arm64" if platform == "android" else "ios_sim_arm64"
                    ]
                    cpu.append(report["cpuProxy"]["processCpuMs"])
                else:
                    assert report["success"] and report["completed_scenes"] == 5
                    assert report["backend"] == ("full_tgfx" if backend == "tgfx" else "skia")
                    assert report["ndebug"] and report["compiler_optimized"]
                    assert report["width"] == 360 and report["height"] == 640
                    assert report["warmup_frames"] == 30 and report["measured_frames"] == 300
                    assert report["on_screen_fps"] is None and report["energy_joules"] is None
                    assert report["gpu_api"] == ("metal" if platform == "ios" else "opengl_es")
                    scenes = report["scenes"]
                    assert [s["name"] for s in scenes] == expected[family]
                    cpu.append(sum(s["process_user_cpu_ms"] + s["process_system_cpu_ms"]
                                   for s in scenes))
                processed = []
                for scene in scenes:
                    if family == "managed":
                        assert scene["status"] == "PASS" and scene["completed"]
                        assert scene["warmupCount"] == 30 and scene["measuredCount"] == 300
                        assert scene["width"] == 360 and scene["height"] == 640
                        assert scene["first"]["passed"] and scene["last"]["passed"]
                        assert scene["outputRelationshipPassed"] and not scene["assets"]["errors"]
                        durations = scene["durationsMs"]
                        assert len(scene["warmupDurationsMs"]) == 30
                        assert abs(statistics.mean(durations) - scene["summary"]["meanMs"]) < 1e-9
                        phases = scene["phaseDurationsMs"]
                        assert all(len(v) == 300 for v in phases.values())
                        if scene["id"] == "lottie":
                            assert scene["first"]["hash"] != scene["last"]["hash"]
                    else:
                        assert scene["success"] and scene["canaries_complete"]
                        assert scene["warmup_completed"] == 30 and scene["measured_completed"] == 300
                        durations = scene["frame_ms"]
                        assert abs(statistics.mean(durations) - scene["frame_mean_ms"]) < 1e-8
                        phases = {}
                        if scene["name"] == "lottie":
                            assert scene["first_fnv1a64"] != scene["last_fnv1a64"]
                            assert scene["changed_pixels"] > 0
                    assert len(durations) == 300
                    assert all(math.isfinite(v) and v > 0 for v in durations)
                    processed.append({
                        "meanMs": statistics.mean(durations),
                        "p95Ms": nearest(durations, .95),
                        "throughput": 1000 / statistics.mean(durations),
                        "phases": {k: statistics.mean(v) for k, v in phases.items()},
                    })
                runs.append(processed)
            result = {"scenes": {}, "fixedWorkProcessCpuMs": aggregate(cpu)}
            for index, name in enumerate(expected[family]):
                values = [run[index] for run in runs]
                entry = {key: aggregate([v[key] for v in values])
                         for key in ["meanMs", "p95Ms", "throughput"]}
                if family == "managed":
                    entry["phaseMeanMs"] = {
                        name: aggregate([v["phases"][name] for v in values])
                        for name in values[0]["phases"]
                    }
                result["scenes"][name] = entry
            backends[backend] = result
        comparison = {}
        for name in expected[family]:
            skia = backends["skia"]["scenes"][name]["meanMs"]["median"]
            tgfx = backends["tgfx"]["scenes"][name]["meanMs"]["median"]
            comparison[name] = {
                "tgfxToSkiaTimeRatio": tgfx / skia,
                "tgfxTimeChangePercent": 100 * (tgfx / skia - 1),
                "tgfxThroughputChangePercent": 100 * (skia / tgfx - 1),
            }
        summary["measurements"][family][platform] = {
            "backends": backends, "comparison": comparison,
        }

sizes = json.loads((E / "final-release-host-sizes.json").read_text())
for backend, value in sizes.items():
    assert digest(Path(value["apk"])) == value["apkSha256"]
summary["sizes"] = {
    "androidRuntime": json.loads((E / "android-release-runtime-size.json").read_text()),
    "iosSimulatorRuntime": json.loads((E / "ios-release-runtime-size.json").read_text()),
    "iosSizeOnlyNormalizedCopies": json.loads((E / "ios-symbol-normalization.json").read_text()),
    "hosts": {
        backend: {key: value[key] for key in [
            "apk", "apkBytes", "apkSha256", "nativeLibraries",
            "iosSimulatorApp", "iosSimulatorBundleBytes",
        ]} for backend, value in sizes.items()
    },
}
summary["validation"] = {
    "formalReports": len(report_hashes),
    "formalMeasuredFrames": 32400,
    "allRequiredScenesAndCanariesPass": True,
    "sourceEnvelopesUnchanged": True,
    "probesExcluded": True,
    "iosVariability": "Large across-run spread; no significance or stable-device speedup claim",
}
assert len(report_hashes) == 24
(E / "summary.json").write_text(json.dumps(summary, indent=2))

for family in expected:
    print(family)
    for platform, value in summary["measurements"][family].items():
        print(platform)
        for name, change in value["comparison"].items():
            skia = value["backends"]["skia"]["scenes"][name]["meanMs"]["median"]
            tgfx = value["backends"]["tgfx"]["scenes"][name]["meanMs"]["median"]
            print(f"  {name:14s} {skia:.4f} -> {tgfx:.4f} ms ({tgfx/skia:.2f}x)")
print("Verified", len(report_hashes), "formal reports")
